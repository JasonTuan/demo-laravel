<?php

return [
    'dir_base' => env('DIR_BASE'),
];
