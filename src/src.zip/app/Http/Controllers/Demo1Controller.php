<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Demo1Controller extends Controller
{
    public function index()
    {
        $name = "Hai";
        return view('demo1', [
            'name' => $name
        ]);
    }
}
