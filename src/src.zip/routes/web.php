<?php

use App\Http\Controllers\Demo1Controller;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

//Route::get(
//    '/',
//    [HomeController::class, 'index']
//)->name('homepage');

Route::prefix('demo1')->group(function () {
    Route::get('/index', [Demo1Controller::class, 'index']);
});
